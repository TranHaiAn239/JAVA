package com.example.language.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LanguageServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String lang = request.getParameter("lang");
        HttpSession session = request.getSession();
        session.setAttribute("lang", lang);

        if ("en".equals(lang)) {
            session.setAttribute("greeting", "Hello");
        } else if ("vi".equals(lang)) {
            session.setAttribute("greeting", "Xin chào");
        }

        response.sendRedirect("greeting.jsp");
    }
}
