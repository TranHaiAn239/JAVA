package com.example.language.listener;

import javax.servlet.*;

public class ContextListener implements ServletContextListener {
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Ứng dụng đã được khởi động");
    }

    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Ứng dụng đã bị tắt");
    }
}
