package com.example.language.filter;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LanguageFilter implements Filter {
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        String lang = request.getParameter("lang");
        if (lang != null && !(lang.equals("en") || lang.equals("vi"))) {
            ((HttpServletResponse) response).sendRedirect("form.html");
        } else {
            chain.doFilter(request, response);
        }
    }
}
